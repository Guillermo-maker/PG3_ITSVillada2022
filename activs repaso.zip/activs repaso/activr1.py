from operator import index

listanum = [8,12,9,45]

print (listanum)

input = int(input("Que numero quieres buscar: "))

index = listanum.index(input)

print (index)